// Native official product artwork; provenance and transformations are recorded in vendor/brand-logos/vercel-platforms/.
export const vercelPlatformLogos = {
  "ai-sdk": {
    "viewBox": [
      0.0,
      0.0,
      311.0,
      90.0
    ],
    "paths": [
      {
        "d": "M2.97269 86L32.6687 3.64H51.1127L80.8087 86H65.0327L58.1887 66.512H25.5927L18.7487 86H2.97269ZM30.0007 53.636H53.7807L41.9487 18.836L30.0007 53.636ZM130.894 3.64V16.748H117.67V72.892H131.59V86H88.5544V72.892H102.59V16.748H89.2504V3.64H130.894Z",
        "fill": "#171717"
      },
      {
        "d": "M190.5 7.5H269.5A37.5 37.5 0 0 1 307 45A37.5 37.5 0 0 1 269.5 82.5H190.5A37.5 37.5 0 0 1 153 45A37.5 37.5 0 0 1 190.5 7.5Z",
        "fill": "none",
        "stroke": "#171717",
        "strokeWidth": 8
      },
      {
        "d": "M183.603 51.8472C184.393 56.468 187.677 59.508 193.088 59.508C197.222 59.508 200.019 57.8664 199.958 54.7048C199.897 51.5432 197.222 49.7192 190.473 48.0776C181.11 45.828 175.091 42.0584 175.091 35.1272C175.091 27.284 181.657 22.3592 191.507 22.3592C201.113 22.3592 207.68 28.2568 208.713 36.9512L199.472 37.4376C198.985 32.8776 195.824 30.02 191.264 30.02C187.251 30.02 184.393 32.0872 184.576 35.2488C184.697 38.8968 188.953 40.1128 193.574 41.268C203.241 43.396 209.382 47.5304 209.382 54.4008C209.382 62.6088 202.147 67.2296 192.845 67.2296C182.326 67.2296 174.909 61.3928 174.301 52.2728L183.603 51.8472ZM226.773 23.332C240.757 23.332 248.601 31.1144 248.601 44.9768C248.601 58.7784 240.879 66.5 227.138 66.5H211.877V23.332H226.773ZM221.119 58.7176H226.773C235.164 58.7176 239.177 54.2792 239.177 44.916C239.177 35.5528 235.164 31.1144 226.773 31.1144H221.119V58.7176ZM250.431 23.332H259.672V42.18L275.359 23.332H286.12L270.252 42.3624L287.093 66.5H276.575L264.172 48.564L259.672 53.7928V66.5H250.431V23.332Z",
        "fill": "#171717"
      }
    ],
    "source": "https://k2mkucxia43oc7fa.public.blob.vercel-storage.com/front/press/ai-sdk-assets.zip",
    "reference": "https://vercel.com/geist/brands",
    "license": "Official Vercel brand artwork; Vercel brand guidelines and trademark rights apply. The package MIT license does not grant rights to these marks.",
    "notes": "Native full AI SDK wordmark paths and original #171717 color from the official press kit. The outlined SDK capsule is converted from its rounded rectangle to an equivalent arc path; letter geometry, layout, and proportions are unchanged. This isometric presentation and the four tonal styles are unofficial identification variants.",
    "assetName": "ai-sdk-logotype-light.svg"
  },
  "nextjs": {
    "viewBox": [
      0.0,
      0.0,
      180.0,
      180.0
    ],
    "paths": [
      {
        "d": "M180 90A90 90 0 1 0 0 90A90 90 0 1 0 180 90Z",
        "fill": "#000000"
      },
      {
        "d": "M149.508 157.52L69.142 54H54V125.97H66.1136V69.3836L139.999 164.845C143.333 162.614 146.509 160.165 149.508 157.52Z",
        "fill": "#FFFFFF"
      },
      {
        "d": "M115 54H127V126H115Z",
        "fill": "#FFFFFF"
      }
    ],
    "source": "https://k2mkucxia43oc7fa.public.blob.vercel-storage.com/front/press/nextjs-assets.zip",
    "reference": "https://vercel.com/geist/brands",
    "license": "Official Vercel brand artwork; Vercel brand guidelines and trademark rights apply. The package MIT license does not grant rights to these marks.",
    "notes": "Native circle-N mark from the official press kit. The source circle and rectangle are converted to equivalent paths and the N path is unchanged. Both white gradient fades are flattened to solid white for this gradient-free collection; the source mask is unnecessary because all retained geometry is inside the circle. These isometric and tonal presentations are unofficial identification variants.",
    "assetName": "nextjs-icon-light-background.svg"
  }
};
